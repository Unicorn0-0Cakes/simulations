# Documentation

| Document | What it is for |
|---|---|
| [literature/literature_matrix.md](literature/literature_matrix.md) | The six-paper core corpus. Bibliographic details verified; every substantive column NOT YET EXTRACTED. Twelve open questions blocking modelling decisions. |
| [literature/extraction_protocol.md](literature/extraction_protocol.md) | How to fill the matrix so its cells mean the same thing in every row. |
| [research/assumption_registry.md](research/assumption_registry.md) | Fifteen registered assumptions with justification, expected effect, uncertainty and sensitivity requirement. The most important file here. |
| [research/research_questions.md](research/research_questions.md) | RQ1–RQ7, each with what must be measured and what currently blocks it. |
| [research/hypotheses.md](research/hypotheses.md) | H1–H4 (mutually contradictory, none endorsed) and seven nulls. |
| [research/validation_strategy.md](research/validation_strategy.md) | Verification, internal validation, empirical validation — kept separate. What is verified and what is not. |
| [research/outcome_typology.md](research/outcome_typology.md) | Why outcome categories are vocabulary, not code. |
| [model/ARCHITECTURE.md](model/ARCHITECTURE.md) | Layer separation, determinism, the three separations the science depends on. |
| [model/STACK_DECISION.md](model/STACK_DECISION.md) | Why NumPy and no ABM framework, and what would reverse the decision. |
| [model/CONFIG_SCHEMA.md](model/CONFIG_SCHEMA.md) | Every configuration key, its bounds, and the assumption it carries. |
| [model/DATA_OUTPUTS.md](model/DATA_OUTPUTS.md) | Output files, size arithmetic, analysis path. |
| [model/ROADMAP.md](model/ROADMAP.md) | Phases 1–6 with entry and exit conditions. |
